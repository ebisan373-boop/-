ボイスムービーつくーる 公開用ファイル

公開方法（GitHub Pages）
1. GitHubにログインし、新しいPublicリポジトリを作成します。
2. このフォルダ内の index.html をリポジトリ直下にアップロードして Commit します。
3. リポジトリの Settings → Pages を開きます。
4. Build and deployment の Source を Deploy from a branch にします。
5. Branch を main、フォルダを /(root) にして Save します。
6. 数分後に表示される https://ユーザー名.github.io/リポジトリ名/ を開きます。

HTTPSのURLから開けば、対応ブラウザでマイクを許可できます。
録音・MOV変換はChrome/Edge推奨。MOV変換にはインターネット接続が必要です。
